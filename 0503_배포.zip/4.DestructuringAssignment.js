// DestructuringAssignment (구조 분해 할당)
// 배열이나 객체에 입력된 값을 개별적인 변수에 할당하는 간편한 방식 제공.

// 배열

// ES6 이전
{
}

// ES6 이후
{
}

// 객체

// ES6 이전

// ES6 이후
// 객체의 property와 변수명이 같을 경우.

// 변수명을 객체의 property명과 다르게 만들 경우.

// 객체를 return 하는 함수.

// ES6 이전

// ES6 이후
