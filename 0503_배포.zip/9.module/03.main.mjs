import { name, age, info, Student } from "./03.declare.mjs";

console.log(name, age);

const result = info();
console.log(result);
