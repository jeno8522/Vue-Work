const name = "안효인";
const age = 30;

function info() {
  return `이름 : ${name}, 나이 : ${age}`;
}

class Student {}

export { name, age, info, Student };
