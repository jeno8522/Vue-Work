export default {
  name: "안효인",
  age: 30,

  info() {
    return `이름 : ${this.name}, 나이 : ${this.age}`;
  },
};
