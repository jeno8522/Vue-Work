<template>
  <div>{{ mapInfo }}</div>
</template>

<script>
export default {
  name: "MainContent1",
  
};
</script>

<style></style>
