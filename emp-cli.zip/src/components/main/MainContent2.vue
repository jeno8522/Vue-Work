<template>
  <div>{{ attractionInfo }}</div>
</template>

<script>
export default {
  name: "MainContent2",
  
};
</script>

<style></style>
