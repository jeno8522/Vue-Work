<template>
  <div id="app">
    <the-header></the-header>
    <emp-list-view></emp-list-view>
    <emp-create-view></emp-create-view>
  </div>
</template>

<script>
import TheHeader from "@/components/TheHeader.vue";
import EmpListView from "./components/emp/EmpListView.vue";
import EmpCreateView from "./components/emp/EmpCreateView.vue";
export default {
  components: {
    TheHeader,
    EmpListView,
    EmpCreateView,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

a {
  text-decoration: none;
}
</style>
