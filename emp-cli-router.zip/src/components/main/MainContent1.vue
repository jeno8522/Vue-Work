<template>
  <div>{{ mapInfo }}</div>
</template>

<script>
export default {
  name: "MainContent1",
  props: {
    mapInfo: String,
  },
};
</script>

<style></style>
